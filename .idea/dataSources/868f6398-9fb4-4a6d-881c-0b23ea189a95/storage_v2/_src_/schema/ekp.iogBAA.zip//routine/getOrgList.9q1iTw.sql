create
    definer = ekp@`%` function getOrgList(rootId varchar(36)) returns varchar(500)
BEGIN DECLARE sTemp VARCHAR (500);

DECLARE sTempChd VARCHAR (500);

SET sTemp = '$';

SET sTempChd = cast(rootId AS CHAR);

WHILE sTempChd IS NOT NULL DO SET sTemp = concat(sTemp, ',', sTempChd);

SELECT group_concat(fd_parentid) INTO sTempChd FROM sys_org_element WHERE fd_org_type=2 and FIND_IN_SET(fd_id, sTempChd) > 0 AND fd_id <> fd_parentid;

END WHILE;

RETURN sTemp;

END;

